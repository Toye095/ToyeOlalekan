#!/usr/bin/env python
# coding: utf-8

# ## a. Importing Libraries

# In[1]:


import random # to generate random numbers


# ## b. Workers Payment Slip

# In[8]:


# 1.Generate list of workers with random attributes

workers = [
    {
        "id": i + 1,        # creates incremented identification for workers
        "name": f"Worker_{i + 1}",     # creates workers name
        "salary": random.randint(5500, 35500), # creates randon salalries between 5000 and 30000
        "gender": random.choice(["M", "F"]) # assigns gender male and female to workers
    }
    for i in range(400)   # ensure that the incremented randomly generated attributes are restrcited to 400
]


# 2.Function to generate payment slips with conditions

def generate_payment_slips(workers):  #A function called generate_payment_slips which accepts one input parameter (workers)
    payment_slips = []        #initialize an empty list to store each workers payment slip 
    for worker in workers:    # to iterate over worker
        try:
            level = "N/A"     # a default employee level for employees who do not meet the level conditions
            if 10000 < worker["salary"] < 20000:
                level = "A1"
            elif 7500 < worker["salary"] < 30000 and worker["gender"] == "F":
                level = "A5-F"

            # Create payment slip
            slip = (
                f"Payment Slip for {worker['name']}:\n"
                f"ID: {worker['id']}\n"
                f"Salary: ${worker['salary']}\n"
                f"Gender: {worker['gender']}\n"
                f"Employee Level: {level}\n"
            )        # generates workers id, name, gender, salary and level

            payment_slips.append(slip) # adds the generated slips to the payment_slips list
        except Exception as e:       # catches any errors encountered in the payment slip generation process
            print(f"Error processing payment slip for {worker['name']}: {e}")
    
    return payment_slips

# 3.Generate and print payment slips for each worker
payment_slips = generate_payment_slips(workers) # call the function and input the parameter
for slip in payment_slips:
    print(slip)


# ## Details

# * Generation of random data: list comprehension was used to creates 400 workers with random salaries between $5,500 and $35,500 dollars and random genders. Each worker is represented by a dictionary containing id, name, salary, and gender.
# 
# * Applying 'For Loop' and specified conditions: The 'generate_payment_slips' function uses a for loop to go through each worker. Based on salary and gender, it assigns an employee level (A1 or A5-F).
# 
# * Error Handling using 'try, except': If there’s an issue processing a worker, it catches the exception, prints an error message, and continues.
# 
# * Payment Slips Output: Each payment slip is then formatted and stored in a list, which is then printed.
