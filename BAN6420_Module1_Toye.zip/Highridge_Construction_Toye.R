# Generate list of workers with random attributes
set.seed(123) # for reproducibility
workers <- list()

for (i in 1:400) {
  workers[[i]] <- list(
    id = i,
    name = paste("Worker", i, sep = "_"),
    salary = sample(5500:35500, 1),
    gender = sample(c("M", "F"), 1)
  )
}

# Function to generate payment slips with conditions
generate_payment_slips <- function(workers) {
  payment_slips <- list()
  
  for (worker in workers) {
    level <- "N/A"
    if (worker$salary > 10000 && worker$salary < 20000) {
      level <- "A1"
    } else if (worker$salary > 7500 && worker$salary < 30000 && worker$gender == "F") {
      level <- "A5-F"
    }
    
    # Create payment slip
    slip <- paste(
      "Payment Slip for", worker$name, ":\n",
      "ID:", worker$id, "\n",
      "Salary: $", worker$salary, "\n",
      "Gender:", worker$gender, "\n",
      "Employee Level:", level, "\n"
    )
    
    payment_slips <- append(payment_slips, list(slip))
  }
  
  return(payment_slips)
}

# Generate and print payment slips for each worker
payment_slips <- generate_payment_slips(workers)

# Print each payment slip without using cat for the entire list
for (slip in payment_slips) {
  cat(slip, "\n\n")
}
